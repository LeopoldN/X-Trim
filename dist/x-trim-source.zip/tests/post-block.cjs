const {chromium}=require('playwright'),assert=require('node:assert/strict'),path=require('node:path');
(async()=>{
 const browser=await chromium.launch({headless:true}),page=await browser.newPage();
 await page.route('https://x.com/**',r=>r.fulfill({contentType:'text/html',body:'<html><body><article data-testid="tweet"><div data-testid="User-Name"><a href="/example">Example</a></div><div style="display:flex"><div><button aria-label="Grok actions">Grok</button></div><button data-testid="caret">More</button></div></article></body></html>'}));await page.goto('https://x.com/home');
 await page.evaluate(()=>{window.prefs={enabled:true,postBlock:true};window.confirmed=0;window.browser={runtime:{onMessage:{addListener:f=>window.blockMessage=f}},storage:{local:{get:async d=>({...d,...prefs})},onChanged:{addListener:f=>window.changed=f}}};document.querySelector('[data-testid="caret"]').onclick=()=>{const menu=document.createElement('div');menu.setAttribute('role','menu');const block=document.createElement('button');block.dataset.testid='block';block.textContent='Block @'+document.querySelector('[data-testid="User-Name"] a').pathname.slice(1);block.onclick=()=>{menu.remove();const dialog=document.createElement('div');dialog.dataset.testid='confirmationSheetDialog';dialog.setAttribute('role','dialog');const confirm=document.createElement('button');confirm.textContent='Confirm block';confirm.onclick=()=>confirmed++;dialog.append(confirm);document.body.append(dialog);};menu.append(block);document.body.append(menu);};});
 await page.addStyleTag({path:path.resolve('content/post-block.css')});await page.addScriptTag({path:path.resolve('content/post-block.js')});
 const originalHeight=await page.locator('[data-testid="caret"]').evaluate(el=>el.parentElement.getBoundingClientRect().height);
 const block=page.getByRole('button',{name:'Block @example',exact:true});await block.waitFor();assert.equal(await page.locator('[data-testid="caret"]').evaluate(el=>el.parentElement.getBoundingClientRect().height),originalHeight);assert(await block.evaluate(b=>b.nextElementSibling.querySelector('[aria-label="Grok actions"]')!==null));await block.click();await page.getByRole('dialog').waitFor();assert.equal(await page.evaluate(()=>confirmed),0);
 await page.evaluate(()=>{document.querySelector('[role="dialog"]').remove();document.querySelector('[data-testid="User-Name"] a').href='/second';document.querySelector('[data-testid="User-Name"] a').textContent='Second';});
 await page.getByRole('button',{name:'Block @second',exact:true}).click();await page.getByRole('dialog').waitFor();assert.equal(await page.evaluate(()=>confirmed),0);
 await page.evaluate(()=>blockMessage({type:'block-state',states:{second:true}}));
 await page.getByRole('button',{name:'Blocked @second',exact:true}).waitFor();
 assert.equal(await page.locator('.xtrim-post-block').evaluate(el=>getComputedStyle(el).color),'rgb(244, 33, 46)');
 await page.evaluate(()=>blockMessage({type:'block-state',states:{second:false}}));await page.getByRole('button',{name:'Block @second',exact:true}).waitFor();
 assert.equal(await page.locator('.xtrim-is-blocked').count(),0);
 await page.evaluate(()=>{prefs.postBlock=false;changed({postBlock:{}},'local');});await page.waitForFunction(()=>!document.querySelector('.xtrim-post-block'));
 await browser.close();console.log('PASS block placement, native confirmation handoff, recycled author and disable cleanup');
})().catch(e=>{console.error(e);process.exitCode=1;});
