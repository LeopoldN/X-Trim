# Submission checks — X Trim 0.7.1

## Rerun for 0.7.1

Checked October 25, 2026. 0.7.1 = 0.7.0 plus a fix in `popup/popup.js`. These are local pre-update checks, not Mozilla approval.

- Sidebar tab: opening the popup on a page that shows only part of X's sidebar (Chat, Calls or a narrow window) replaced the saved list with that short one. The popup now merges each visit into the saved list, and keeps listing links you switched off. Search also finds sidebar links by their section name.
- Account details: when the background About request fails before reaching X (for example blocked by privacy settings or another extension), the background asks the X tab to make the same request as the page (`content.fetch` in Firefox) to the same `x.com/i/api/graphql/…/AboutAccountQuery` address with the same headers, after the same consent and preference checks. The content script only accepts that exact same-origin path. A reply that is not JSON now shows "X sent an unexpected reply" instead of the network message. `tests/policy-checks.cjs` covers the fallback, its failure and a non-JSON reply.
- X access: the browser can keep the required x.com/twitter.com host access at "only when clicked", so X Trim did nothing on X until its toolbar button was clicked, and background requests to X failed (the likely cause of the account-details network message). New `background/site-access.js` shows a "!" badge on the toolbar button while access is limited, and the popup shows an **Always allow on X** button that calls `permissions.request` for the existing `host_permissions` origins, then reloads the open X tab. Nothing is requested without that click.
- No new permissions, hosts or data destinations.

## Rerun for 0.7.0

Checked October 25, 2026. 0.7.0 = 0.6.1 plus a redesigned toolbar popup. These are local pre-update checks, not Mozilla approval.

- Only `popup/popup.html`, `popup/popup.css` and `popup/popup.js` changed, plus version numbers and README. The popup is now 680×560 with a labelled section list, a Home tab (presets and quick toggles), settings search, a Show/Hide map on Trim and a live theme preview. Every setting keeps its storage key and element ID, so saved preferences carry over.
- Presets and quick toggles write the same storage keys as the existing switches. Search only filters the popup's own controls. No new permissions, requests or host permissions; CSP, `data_collection_permissions` and the extension ID are unchanged.

## Rerun for 0.6.1

Checked October 24, 2026. 0.6.1 = 0.6.0 plus an extension icon for Firefox. These are local pre-update checks, not Mozilla approval.

- 0.6.0 and earlier had no `icons` or `action.default_icon` in `manifest.json`, so Firefox showed its generic puzzle-piece icon in the toolbar and Add-ons Manager. The manifest now points both at the new `icons/x-trim.svg`, the popup's scissors mark on its mint tile, which reads on light and dark toolbars.
- No other file changed apart from version numbers. No new permissions, requests or host permissions; CSP, `data_collection_permissions` and the extension ID are unchanged. The SVG is left out of the Chrome ZIP, which keeps its PNGs in `chrome/icons`.
- `python3 scripts/package.py` rebuilt all four archives. Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. All `tests/*.cjs` files pass.


## Rerun for 0.6.0

Checked October 24, 2026. 0.6.0 = 0.5.3 plus a separate Chrome Web Store build. These are local pre-update checks, not Mozilla approval.

- The Firefox XPI has the same files as 0.5.3. Only `manifest.json` (version), `PRIVACY.md` (version and a Chrome consent sentence) and `background/media-download.js` changed. That file now names its response reader `readXResponse()` and its on/off check `responseCaptureEnabled()`, and registers the Firefox response filter only where `browser.webRequest.filterResponseData` exists, which is always true in Firefox. Same requests, permissions, filters and behavior; CSP, `data_collection_permissions` and the extension ID are unchanged.
- New `chrome/` folder (manifest, icons, shims) is packaged only into `dist/x-trim-chrome.zip`. `scripts/package.py` fails if `chrome/manifest.json` drifts from `manifest.json` (name, version, description, hosts, commands, CSP, content scripts and background scripts).
- New `tests/chrome-build.cjs` builds the Chrome ZIP and loads it in Playwright's Chromium against local x.com fixtures: the service worker starts, X's XHR and fetch replies reach the background readers, forged replies from other paths are ignored, promise replies work both ways, data consent reaches the background, and the popup has no Firefox wording.
- `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip`, `x-trim-chrome.zip` and `x-trim-source.zip`. Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check`, and all `tests/*.cjs` files pass. The Firefox build has not been run in Firefox in this environment.

The 0.5.3 and earlier notes below still apply.

## Rerun for 0.5.3

Checked October 24, 2026. 0.5.3 = 0.5.2 plus optional custom widths for X's full Chat and Calls pages. These are local pre-update checks, not Mozilla approval.

- Popup › Layout gains a Chat and Calls section: two switches (off by default) with 480–1600 px sliders, stored as `chatCustomWidth`/`chatWidth` and `callsCustomWidth`/`callsWidth` in `storage.local`. Reset widths clears them too.
- `content/layout.js` sizes `primaryColumn` on `/i/chat`, `/messages` and `/i/calls` (via `xtrimPagePath()`) and leaves X's own nav rail alone there. A Calls width above X's own 1280 px cap adds one style element to the Calls page's open shadow root. Hide right column no longer squeezes these pages, which have no right column, to 600 px. No new files besides the test, no new permissions, requests or host permissions; CSP, `data_collection_permissions` and the extension ID are unchanged.
- New `tests/chat-calls-width.cjs` checks the default (unchanged), each page's own width, the Calls cap being lifted and restored, popups keeping the width, small windows and other pages.
- `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` and `x-trim-source.zip`. Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check`, and all `tests/*.cjs` files pass. The build has not been run in Firefox in this environment.

The 0.5.2 and earlier notes below still apply.

## Rerun for 0.5.2

## Rerun for 0.5.2

Checked October 24, 2026. 0.5.2 = 0.5.1 plus custom-theme coverage for X's full Chat and Calls pages. These are local pre-update checks, not Mozilla approval.

- `content/theme.js` already wrote its palette into the chat drawer's shadow roots. It now finds every X app shadow root, the hosts X names `xchat*` or `xcalls*` (Chat page, Calls page, chat drawer and overlays) and body-level roots that hold X's `[data-theme]` wrapper, and sets the palette on `[data-theme]` instead of every element so X's locally remapped button tokens keep working. It also maps the list divider, subtle row hover and secondary-button hover and pressed tokens. No new files, permissions, requests or host permissions; CSP, `data_collection_permissions` and the extension ID are unchanged.
- New `tests/chat-calls-theme.cjs` checks the Calls and Chat page roots, a body-level portal, that an unrelated shadow root is left alone, and that turning the theme off restores X's colors. `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` and `x-trim-source.zip`.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and all `tests/*.cjs` files pass. The build has not been run in Firefox in this environment.

The 0.5.1 and earlier notes below still apply.

## Rerun for 0.5.1

Checked October 24, 2026. 0.5.1 = 0.5.0 plus one option on the popup's Posts tab: hide the Grok button beside each post's More menu. It is off by default. These are local pre-update checks, not Mozilla approval.

- `content/usability.js` sets one more root flag from the new `hidePostGrok` preference, and `content/usability.css` hides the post's "Grok actions" button and its wrapper behind that flag. No new files in the package, no new requests. `content/post-block.js` sizes its Block button from the More button when the Grok button is hidden. Permissions, host permissions, optional permissions, CSP, `data_collection_permissions` and the extension ID are unchanged.
- New `tests/post-grok.cjs` checks the hiding, the Block button's size and spacing beside More, and that turning the option or X Trim off restores Grok, on a fixture that follows the live post header. `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` and `x-trim-source.zip`.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and all `tests/*.cjs` files pass. The build has not been run in Firefox in this environment.

The 0.5.0 and earlier notes below still apply.

## Rerun for 0.5.0

Checked October 24, 2026. 0.5.0 = 0.4.4 plus Explore page options on the popup's Trim tab: hide the Sports scores and league row, Today's News, trends and topics, Who to follow, or Posts for you on the main Explore tab. All five are off by default. These are local pre-update checks, not Mozilla approval.

- New content script `content/explore.js` and style `content/explore.css`, appended to the existing content script lists. The script labels each Explore timeline cell with its section from X's test IDs and structure (never its text), and the style hides labelled cells behind root flags set only on the Explore tab. It sends no requests and reads no responses. Permissions, host permissions, optional permissions, CSP, `data_collection_permissions` and the extension ID are unchanged.
- New `tests/explore.cjs` checks every section on a fixture that follows the live Explore page, including spacers, cells X drops while scrolling, a popup over Explore, the master switch and the other Explore tabs. `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` and `x-trim-source.zip`.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and all `tests/*.cjs` files pass. The build has not been run in Firefox in this environment.

The 0.4.4 and earlier notes below still apply.


## Rerun for 0.4.4

Checked October 24, 2026. 0.4.4 = 0.4.3 with the files reorganized into folders and no change in behavior. These are local pre-update checks, not Mozilla approval.

- Files moved into `content/` (content scripts and styles), `background/` (background page scripts), `shared/` (`data-consent.js`), `popup/`, `gif-converter/` and `dist/` (built archives). Renamed: `content.js` → `content/layout.js`, `early-layout.css` → `content/layout-early.css`, `about-profile.js`/`.css` → `content/account-details.js`/`.css`, `about-background.js` → `background/account-details.js`, `gif-background.js` → `background/gif-conversion.js`, `block-state.js` → `background/post-block.js`, `usability-background.js` → `background/usability.js`, `media-background.js` → `background/media-download.js`, `media-gif.js` → `gif-converter/mp4-to-gif.js`. Other files kept their names. Entries for older versions below use the file names of their release.
- Content scripts, content styles and background scripts load in the same order as 0.4.3. Permissions, host permissions, optional permissions, CSP, `data_collection_permissions`, the extension ID and requests are unchanged. `vendor/gif.js` is unchanged and at the same path; both runtime scripts still match the SHA-256 values in `review/vendor-provenance.json`.
- The rebuilt XPI was compared with the 0.4.3 XPI file by file under the rename map: 31 of 37 files are byte-identical. The only differences are the version in `manifest.json` and `PRIVACY.md`, the manifest paths, the conversion page path in `background/gif-conversion.js`, the script paths in `popup/popup.html` and `gif-converter/gif-converter.html`, and one comment naming a renamed file in `content/usability.js`.
- `python3 scripts/package.py` now writes `x-trim.xpi`, `x-trim.zip` (identical to the XPI) and `x-trim-source.zip` to `dist/`, still from an explicit file list.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and all `tests/*.cjs` files pass with their paths updated. The popup and GIF conversion pages were opened from the extracted XPI and loaded every script and stylesheet. The build has not been run in Firefox in this environment.

The 0.4.3 and earlier notes below still apply.

## Rerun for 0.4.3

Checked October 23, 2026. 0.4.3 = 0.4.2 plus a fix: when X opens a popup on a URL of its own (Edit profile at /settings/profile, the composer at /compose/post, the photo viewer at /name/status/1/photo/1, and others) while the page underneath stays rendered, that page now keeps X Trim's layout, profile options and theme. Before, every feature read the popup's URL and treated the background as a different page. These are local pre-update checks, not Mozilla approval.

- New `page-route.js` runs first in the existing content script list and gives the other scripts one shared `xtrimPagePath()`. While a modal dialog in X's popup layer has opened together with a URL change, it returns the path from before the popup; drawers and dialogs that never changed the URL are ignored. Page-level route checks in `content.js`, `about-profile.js`, `theme.js`, `usability.js` and `geo-timeline.js` use it. Code that acts on the popup itself (photo viewer downloads, account details for an opened post) still reads the real URL. Permissions, CSP, `data_collection_permissions` and requests are unchanged.
- New `tests/popup-route.cjs` opens Edit profile, an unknown popup route, a popup whose dialog mounts after the URL change and the photo viewer over a profile or post, and checks that a drawer never pins the page across real navigation. `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` and `x-trim-source.zip`.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and all `tests/*.cjs` files pass.

The 0.4.2 and earlier notes below still apply.

## Rerun for 0.4.2

Checked October 23, 2026. 0.4.2 = 0.4.1 plus a popup fix: after scrolling a popup tab, clicking a switch, tile or choice no longer pushes the whole popup up and leaves an empty area under the footer. The visually hidden checkboxes and radios had no positioned ancestor, so focusing one scrolled the popup document instead of the settings panel. `popup.css` now positions the header, the panel and every label. These are local pre-update checks, not Mozilla approval.

- Only `popup.css` changed. Permissions, CSP, `data_collection_permissions`, scripts and requests are unchanged. `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` and `x-trim-source.zip`.
- In Chromium with a stubbed `browser` API, clicking all 90 popup controls across the eight tabs after scrolling each panel to the bottom left the popup document at scroll 0. Before the fix the same clicks scrolled it by up to 1,570 px. The fix has not been run in Firefox in this environment.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and all `tests/*.cjs` files pass.

The 0.4.1 and earlier notes below still apply.

## Rerun for 0.4.1

Checked October 23, 2026. 0.4.1 = 0.4.0 plus a fix: Profile options (font, width, square avatar, avatar border, post count, account details, themed profile header) now stay on every profile timeline tab, including /name/all, /name/reposts, /name/superfollows and /name/affiliates, and on any other tab linked from X's own "Profile timelines" tab bar. Post, follower, list and settings routes are still excluded. Move post count beside Followers now also moves the header count X shows on other tabs, such as "photos & videos" on Media and "likes" on Likes. These are local pre-update checks, not Mozilla approval.

- Permissions, host permissions, optional permissions, CSP, `data_collection_permissions` and the content script list are unchanged. Only route matching in `content.js`, `about-profile.js` and `theme.js` changed; no new requests are made.
- New `tests/profile-tabs.cjs` checks the profile options on each tab and their absence on non-profile routes. `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` and `x-trim-source.zip`.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and all eight `tests/*.cjs` files pass. The fix has not been run in Firefox in this environment.

The 0.4.0 and earlier notes below still apply.

## Rerun for 0.4.0

Checked October 23, 2026. 0.4.0 = 0.3.5 plus usability options, all off by default: Following tab controls, hiding promoted / Paid partnership / #ad posts, hiding counts or the action bar, exact counts and absolute / 24-hour times, keyword, regex, no-media and Premium-reply filters, focus and writer modes, new-post auto-load or hiding, fast block, a daily time limit, Media tab on Photos, and hiding the own-profile X Money button with Sidebar › Money. These are local pre-update checks, not Mozilla approval.

- Permissions, host permissions, optional permissions, CSP and `data_collection_permissions` are unchanged. The manifest adds the content script `usability.js` with `usability.css`, the background script `usability-background.js`, and a `commands` entry (Alt+Shift+F, toggles focus mode).
- `usability-background.js` reads promoted, paid-partnership, verification and following flags from X's existing GraphQL responses through the same pass-through response filter, only while the related filters are on, and messages them to the tab. Nothing is sent off the device or written to disk except `usageToday` (today's minutes) when the daily limit is on.
- Keep Following sorted by Recent wraps X's page `XMLHttpRequest.open`/`send` with `exportFunction` and sets only `enableRanking` to false on X's own `HomeLatestTimeline` request.
- Fast block clicks X's own `confirmationSheetConfirm` only within 3 seconds of the user choosing a Block menu item; `post-block.js` itself still never confirms.
- Selectors were checked against live x.com markup captured read-only on October 23, 2026 (tabs, new-posts pill, action-bar aria-labels, verified badges, the Paid partnership policy link, the own-profile `ownProfilePaymentsButton`, the profile Videos/Photos menu). No live ad was found to sample; promoted posts rely on X's `promotedMetadata` with an "Ad" label fallback. `placementTracking` is not used, since it also wraps every video.
- `content.js` now ignores storage changes to keys it does not use, so the usage counter does not trigger its passes.
- New `tests/usability.cjs` covers every option above with local fixtures plus the background parsing and counter. `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` and `x-trim-source.zip`.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and all seven `tests/*.cjs` files pass. The changes have not been run in Firefox in this environment.

The 0.3.5 and earlier notes below still apply and were not rerun except where stated above.

## Rerun for 0.3.5

Checked October 23, 2026. 0.3.5 = 0.3.0 plus performance fixes for the custom theme, mainly so switching photos in X's photo viewer is smooth again. These are local pre-update checks, not Mozilla approval.

- Manifest permissions, host permissions, optional permissions, CSP, content script list and `data_collection_permissions` are unchanged from 0.3.0. Only the version changed.
- `theme.js` no longer rescans the whole page on every DOM change. It classifies only nodes X added, plus elements whose class or inline color changed, and skips inline style changes that touch no color property (X's slide and fade animations). The whole page is still scanned on load, on resize and when theme settings change. Nothing new is read or sent.
- `content.js` skips passes for DOM changes made only inside a modal dialog such as the photo viewer. `post-block.js` measures the Grok button once per Block button instead of on every scan.
- New `tests/theme-incremental.cjs` checks that animation-only style changes trigger no style reads, that added and restyled nodes are still themed without a full-page scan, and that palette changes rescan. A headless Chromium benchmark on a synthetic 4,150-element post page with 10 simulated photo swaps cut the theme's main-thread time from about 1,900 ms to about 110 ms; tagging results on a mixed fixture were identical to 0.3.0.
- `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` (identical to the XPI) and `x-trim-source.zip`, now including `tests/theme-incremental.cjs`.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and all six `tests/*.cjs` files pass. The changes have not been run in Firefox in this environment.

The 0.3.0 and earlier notes below still apply and were not rerun except where stated above.

## Rerun for 0.3.0

Checked October 23, 2026. 0.3.0 = 0.2.0 plus a Dim theme preset (`theme-presets.js`), Theme tab controls (`popup.html`, `popup.css`, `popup.js`) and a new content script, `theme-extras.js`. These are local pre-update checks, not Mozilla approval.

- Manifest permissions, host permissions, optional permissions, CSP and `data_collection_permissions` are unchanged from 0.2.0. Only the version and the content script list (adding `theme-extras.js`) changed.
- `theme-extras.js` reads only X Trim's own settings from `storage.local` and sends nothing. It adds CSS for a site-wide font, post text size, post spacing, hidden divider lines and accent-colored Follow buttons. With the optional plain post text setting on, it rewrites Unicode bold/italic letters to plain letters in post text only, and restores them when turned off.
- The Custom CSS box is empty by default. Its CSS goes into a `<style>` element on X; `@import` rules are stripped, so it cannot load remote stylesheets, and nothing in it runs as script.
- `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` (identical to the XPI) and `x-trim-source.zip`, now including `theme-extras.js` and `tests/theme-extras.cjs`.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive as before. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22, and `tests/policy-checks.cjs`, `tests/account-card.cjs`, `tests/geo-timeline.cjs`, `tests/post-block.cjs` and the new `tests/theme-extras.cjs` pass.
- Selectors for post spacing, dividers and Follow buttons come from x.com's live markup on October 23, 2026. The new features have not been run in Firefox in this environment.

The 0.2.0 and earlier notes below still apply and were not rerun except where stated above.

## Rerun for 0.2.0

Checked October 23, 2026. 0.2.0 = 0.1.77 plus the tabbed toolbar popup redesign (`popup.html`, `popup.css`, `popup.js`) and a theme fix for X's chat drawer (`theme.js`). These are local pre-update checks, not Mozilla approval.

- Manifest permissions, host permissions, optional permissions, CSP and `data_collection_permissions` are unchanged from 0.1.77; only the version changed.
- `theme.js` now also writes the theme palette into a `<style>` element inside the open shadow roots X uses for its chat drawer (`xchatEmbedDrawer`, `xchatEmbedOverlays`). It reads nothing from them and sends nothing. Before this, the chat button turned back to X's native colors after the drawer was opened and closed.
- Popup and download error messages that pointed to the old "Post page" section now say "Posts", which matches the new tab names. README, listing and reviewer notes are updated the same way.
- `python3 scripts/package.py` rebuilt `x-trim.xpi`, `x-trim.zip` (identical to the XPI) and `x-trim-source.zip`.
- Mozilla web-ext **10.8.0** lint of the extracted rebuilt XPI: **0 errors, 0 notices, 1 warning**, the same gif.js `platform.name` false positive described below. Output is in `review/lint.json`.
- All first-party JavaScript passes `node --check` with Node.js 22.22.0, and `tests/policy-checks.cjs`, `tests/account-card.cjs`, `tests/geo-timeline.cjs` and `tests/post-block.cjs` pass.
- The chat drawer fix was checked on live x.com in Chrome, with `theme.js` injected and storage stubbed: the drawer and the chat button kept the custom palette through open/close cycles. It has not been run in Firefox in this environment.

The 0.1.77 notes below still apply and were not rerun except where stated above.

## 0.1.77 notes

Checked October 23, 2026 against commit `f051d82` (manifest version 0.1.77; the commit message reads "V0.1.76"). These are local pre-update checks, not Mozilla approval or a full independent security audit. X Trim is already listed on AMO; these notes are for the next version upload.

## Rerun for 0.1.77

- The `x-trim.xpi` committed in `f051d82` matched the working tree file for file and rebuilt byte for byte with `python3 scripts/package.py`. After the small fixes below, the XPI was rebuilt; its only content change is the `PRIVACY.md` date line, and `x-trim.zip` is identical to it.
- Mozilla web-ext **10.8.0** scans the complete extracted rebuilt runtime package: **0 errors, 0 notices, 1 warning** (the same vendor false positive as before, below). Exact output is in `review/lint.json`.
- All first-party JavaScript parses with Node.js 22.22.0 (`node --check`); `git diff --check` passes for 0.1.69 to 0.1.77.
- Node tests pass: `tests/policy-checks.cjs` (account consent, private-cache isolation, metadata and timeline scope enforcement; download consent, URL allowlist, ownership, variant matching and response pass-through; optional media consent UI), `tests/account-card.cjs`, `tests/geo-timeline.cjs` and `tests/post-block.cjs`.
- Vendor integrity: the npm archive for gif.js 0.2.0 was downloaded again and matches its published SHA-512 integrity; the packaged `gif.js` and `gif.worker.js` match the release bytes and `review/vendor-provenance.json`.
- Manifest permissions, host permissions, optional permissions, CSP and `data_collection_permissions` are unchanged since 0.1.69. Only content scripts (`geo-timeline.js`, `post-block.js` and their CSS) and one background script (`block-state.js`) were added.

## Features added since 0.1.68

**Account cards (0.1.72).** The About lookup now also returns display name, creation date, user ID, verification type, handle-change count, affiliation and follower/following/post/media counts. Requests, consent and storage are unchanged: the same optional `websiteContent` + `browsingActivity` + `authenticationInfo` consent, X as the only recipient, normal-window results in `aboutCache` (24 hours, at most 100 records), private-window results not written. Counts seen in X's own GraphQL responses are kept in background memory (at most 100 accounts per tab) and cleared on tab close, feature disable or consent revocation.

**Timeline country filtering (0.1.76).** Off by default. Enabling it in the popup requests the same account-data consent; the background handler checks the `geoBlocking` preference and consent again before and after queueing. While enabled with a nonempty country list, authors of posts near the viewport are looked up one at a time through the existing About request (1.5 s spacing, shared rate-limit cooldown, at most 30 pending). This is the one feature that sends a handle the user did not open, so it is the main data point to state plainly for reviewers. Results share the account cache; the content script also keeps up to 500 results in page memory. Filters only change the local view.

**Block shortcut (0.1.76, 0.1.77).** On by default. Adds a button beside X's Grok button that opens the post's own More menu and selects X's native Block item, so X shows its own confirmation and sends its own request. The extension never submits the confirmation and never uses Unblock. It sends no requests. To color already-blocked authors, `block-state.js` reads blocking flags from X's existing responses and keeps up to 1,000 handles in page memory only.

## Findings for the update

1. **Response filtering has a wider scope.** Through 0.1.69, `filterResponseData` ran only while media downloads were enabled. It now also runs while account features or the Block shortcut are on, so turning off downloads no longer turns it off (both download buttons and the shortcut default on). Its URL filter was widened from X GraphQL to also include `/i/api/1.1/blocks/*.json`, and parsed responses now feed account counts and block state as well as media URLs. Nothing is sent anywhere; bytes are still forwarded unchanged as they arrive and buffered up to 8 MB for parsing. The old reviewer notes described the narrower scope, so they are updated.
2. **Reviewer notes and listing were at 0.1.69.** Neither mentioned country filtering or the Block shortcut. Both are updated in this change.
3. **README called the Block button "optional"** without saying it is on by default. Not a policy problem, since it sends nothing. Fixed in the README and stated in the listing.
4. **`PRIVACY.md` effective date** read October 11, 2026, but its Block shortcut paragraph was added on October 23. Fixed to October 23, 2026; the policy text is otherwise unchanged.
5. **The committed source archive included two macOS `.DS_Store` files** under `vendor/`, because `scripts/package.py` collected everything there. The script now skips `.DS_Store`, and the rebuilt source archive contains none.
6. **The latest commit is titled "V0.1.76"** but contains 0.1.77. Packages and docs all say 0.1.77, so AMO is unaffected.

## Linter warning disposition

`UNSUPPORTED_API: platform.name is not supported`, at `vendor/gif.js/dist/gif.js:2:6241`, is a static-analysis false positive. `src/browser.coffee` defines a **local browser-detection object** with its own `platform.name`; it is not a call to Firefox's WebExtension browser API. The release files are intentionally unchanged, per Mozilla's library rules. The two minified vendor files are reported as unknown minified files in metadata, so exact distribution/source links are provided for human review. No first-party file is classified as minified.

## Data declaration and consent

`required: ["none"]`: there is no mandatory transmission. Optional `websiteContent` consent gates media requests. Account details and timeline country filtering additionally require `browsingActivity` and `authenticationInfo` consent. UI and background both enforce consent; queued account operations recheck consent and preferences before fetching. Account details and country filtering default off. The Block shortcut and block-state coloring transmit nothing and need no data consent. X is the only recipient; no developer backend exists. GIF MP4 fetches omit credentials. Private-window conversion tabs stay in their originating window.

This classification follows Mozilla's published taxonomy conservatively; Mozilla reviewers retain authority over the final classification and disclosure wording.

## Carried over from 0.1.68 (not rerun)

GIF conversion, download and cancellation code is unchanged since 0.1.68. The October 10, 2026 browser runs still describe it: standard Firefox 157.0.1 and Zen 1.23.1b, isolated macOS profiles, local MP4 fixture, animated `GIF89a` output, native download completion and cancellation. They were not rerun for 0.1.77 because no Firefox build or MP4 fixture is available in this environment.

No live signed-in X account was used. Account, country-filter and block-state behavior was tested only with synthetic responses and DOM fixtures. X's authenticated API availability, rate limits and page markup (including the Grok button the Block shortcut anchors to, and the More-menu `block` test ID) are external dependencies. No Android, Windows/Linux, Firefox 140 or native-consent-dialog automation was performed.

Mozilla's upload validation, human review and signing happen only after the version is uploaded and are not claimed here. Supply reviewer-controlled X test credentials if requested for authenticated features.

## Reproduce

- Package: `python3 scripts/package.py`.
- Node tests: `for t in tests/*.cjs; do node "$t"; done`.
- Browser test: `python3 tests/firefox-integration.py --browser /path/to/firefox --fixture /path/to/sample.mp4` (isolated temporary profile, localhost fixture server, temporary downloads only).
- Mozilla lint: extract `x-trim.xpi` into an empty directory, then `web-ext lint --source-dir /path/to/extracted-package --output json`.

Policy references: https://extensionworkshop.com/documentation/publish/add-on-policies/ ; https://extensionworkshop.com/documentation/publish/third-party-library-usage/ ; https://extensionworkshop.com/documentation/develop/firefox-builtin-data-consent/ .
