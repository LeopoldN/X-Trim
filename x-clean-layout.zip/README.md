# X Clean Layout — prototype

For Firefox or Zen 140 and newer. Hides Premium promotions and Who to follow by default. The toolbar popup lets you hide each navigation item, including Premium, Creator Studio, your profile, More, Post, and the account menu. Settings stay on this browser; no analytics or external requests. Applies across X, including profiles.

## Try it
1. Unzip the archive.
2. Open `about:debugging#/runtime/this-firefox` in Firefox or Zen.
3. Click **Load Temporary Add-on** and select `manifest.json` from this folder.
4. Open or reload https://x.com. Allow access to X if the browser asks.
5. Click the extension toolbar button (it may be inside the extensions menu). Uncheck sidebar items to hide them. For the profile entry and new menu items, open the popup while X is active. Open X’s More menu before opening the popup to discover supported extra links.

Temporary add-ons disappear when the browser restarts. Permanent installation in ordinary Firefox requires Mozilla signing; this archive is unsigned source, not a store release.

## Limits
This is a first prototype, not verified against a logged-in live X account. X changes its markup frequently. Promotion and suggestion matching currently uses English headings and known X attributes. Creator subscription buttons and text within posts are intentionally preserved. Navigation settings work by destination or button identity. Items X renders outside the header navigation may need additional selectors. If a block remains visible, provide its page markup or a screenshot so its selector can be updated.

## Check
JavaScript syntax and manifest/package structure were checked locally. Test on your account by toggling a navigation item, navigating to a profile, scrolling, and restoring defaults. Confirm posts remain visible and controls restore without reloading.

## Add from More
Open More on X, expand any subsections, then reopen the extension popup and click Refresh More options. Check discovered links to add them to the sidebar. Turn off Replace More with Settings while discovering. Only actual same-site links can be added; submenu expansion buttons remain in More. Added links use a generic arrow icon. Discovery and insertion have local automated checks, but the live More menu still needs verification in Zen.

## Column widths
Enable Use custom widths in the popup, then adjust the navigation, feed, and right-column sliders. Changes apply live. Reset widths disables overrides and restores X’s layout. Custom widths apply at 700px and above; the right column hides if the configured total cannot fit. Live rendering in Zen needs verification.

## Profile page
The collapsible Profile page section controls profile-only width, local font choices, right-column hiding or search-only hiding, and placing the post count after Followers. Profile width takes precedence over the general feed width. Reset profile settings leaves your other settings in place. These controls are scoped to profile routes and profile tabs, not post detail pages. Selectors were checked against your supplied profile HTML; live visual verification in Zen is still needed.

## Profile picture
In Profile page, enable Square profile picture to change the main profile avatar shape. Enable Use custom picture border color to recolor the existing outer ring. The default custom color is Twitter blue (#1DA1F2); use the color picker or a three- or six-digit hex code. Only the main profile avatar is targeted. Reset profile settings restores the original shape and border.

## About account details
Enable Show Based in & Connected via under Profile page. The extension requests X's own AboutAccountQuery using your existing signed-in session. Two compact labels appear next to the profile name, wrapping on narrow columns. Refresh is available beside them. Results are cached locally for 24 hours (up to 100 profiles), requests are deduplicated and paced, and HTTP 429 responses trigger a persistent cooldown. Missing fields show Not provided; rejected, unavailable, or mismatched responses are not cached as real metadata.

This version adds the webRequest permission to observe X web-client authentication headers; only the needed headers are retained in memory and they are not logged, stored on disk, or sent to other sites. Requests go only to X. This is an internal website endpoint and may require updating if X changes it. The request and response shapes were checked against https://github.com/xaitax/x-account-location-device/tree/main/extension/src and the name-row placement against your supplied profile HTML. Local mock tests cover request/cache/rate-limit behavior; a real signed-in request and appearance in Zen remain unverified.

## Post page account details
Enable Show author account details in the collapsible Post page section. On a standard /username/status/id page, the matching opened post gets the same account details beside its author name. Replies and quote authors are not fetched. Profile and post toggles are independent and share the same 24-hour cache. /photo/ and /video/ media routes are supported. Live placement in Zen still needs confirmation.

## Theme
Dark and Light set X’s native night_mode cookie (2 for dark, 0 for light) and reload once when the preference changes. They do not apply extension palette CSS. If cookies are blocked, no automatic reload occurs. X default stops enforcing a theme and leaves X’s current native choice in place.

Custom separately supports six hex colors: background, surfaces, text, muted text, borders, and accent. Native neutral and blue colors are mapped to that palette while photos, videos, and other colors are preserved. Custom overrides and theme-color metadata changes are removed when leaving Custom. Local logic checks passed; native rendering in Zen still needs live verification.

Custom also offers a gradient background: the Background color is the first stop, with a second color and a 0–360° direction slider. It spans the viewport continuously; surface cards keep their selected surface color.

## Media downloads
Post page includes an enabled-by-default download toggle for opened-post GIFs and direct MP4 videos. A Download button uses the browser Save As dialog. GIFs are stored as MP4, as served by X. Stream-only/blob videos and image downloads are not implemented yet. Requires downloads permission.

## Palette presets
Theme dropdown includes Tokyo Night, Rosé Pine, Catppuccin Mocha, Dracula, Nord, and Gruvbox Dark. Selecting one fills all custom colors and disables the gradient. Editing a color switches the dropdown label to Custom. Dark and Light continue to use X's native themes.
Palette sources: https://github.com/folke/tokyonight.nvim, https://rosepinetheme.com/palette/, https://catppuccin.com/palette/, https://draculatheme.com/contribute, https://www.nordtheme.com/docs/colors-and-palettes/, https://github.com/morhetz/gruvbox. Colors are adapted to X's UI roles.
